<?php
/**
 * @package MegaMain
 * @subpackage MegaMain
 * @since mm 1.0
 */
/*
	if( is_admin() ) {
		include_once( 'skin_loader.php' );
	} else {
	}
*/
		include_once( 'skin.php' );
		include_once( 'skin_loader.php' );
?>